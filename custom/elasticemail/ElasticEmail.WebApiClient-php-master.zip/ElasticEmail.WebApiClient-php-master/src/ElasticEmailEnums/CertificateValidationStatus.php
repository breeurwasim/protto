<?php
	namespace ElasticEmailEnums; 

abstract class CertificateValidationStatus
{
    /**
     * 
     */
    const ErrorOccured = -2;

    /**
     * 
     */
    const CertNotSet = 0;

    /**
     * 
     */
    const Valid = 1;

    /**
     * 
     */
    const NotValid = 2;

}
