<?php
	namespace ElasticEmailEnums; 

abstract class ConsentTracking
{
    /**
     * 
     */
    const Unknown = 0;

    /**
     * 
     */
    const Allow = 1;

    /**
     * 
     */
    const Deny = 2;

}
