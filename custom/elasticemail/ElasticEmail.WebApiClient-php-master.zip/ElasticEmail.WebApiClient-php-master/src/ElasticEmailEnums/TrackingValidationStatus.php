<?php
	namespace ElasticEmailEnums; 

abstract class TrackingValidationStatus
{
    /**
     * 
     */
    const Validated = 0;

    /**
     * 
     */
    const NotValidated = 1;

    /**
     * 
     */
    const Invalid = 2;

    /**
     * 
     */
    const Broken = 3;

}
