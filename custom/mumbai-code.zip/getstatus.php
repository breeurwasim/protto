<?php

include "config.php";

$trackingid = $_POST["trackingid"];

//SQL Query

$sql = "SELECT * FROM jos1n_orders WHERE id = '$trackingid';";

$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
    // output data of each row
    while($row = mysqli_fetch_assoc($result)) {
    
    	echo '<div class="row"><div class="col-xs-12 col-sm-12 col-md-12">';

        echo '<h3>Booking Status</h3>';
        
        echo '<h4 style="color: #e33a0c;"><strong>' . $row["status"] . '</strong></h4><br />';
        
        echo '</div></div>';
        
    	echo '<div class="row"><div class="col-xs-6 col-sm-6 col-md-6">';
    	
    	echo '<strong>Booking Details:</strong><br />';
        
        echo 'Booking ID: ' . $row["id"] . '<br />';
        
        echo 'Pickup Date: ' . $row["date"] . '<br />';
        
        echo 'Pickup Time: ' . $row["time"] . '<br />';  
          	
    	echo '</div><div class="col-xs-6 col-sm-6 col-md-6">';
    	
    	echo '<strong>Shipping Address: </strong><br />';
        
        echo  $row["address"] . '<br />';
    	
        echo '</div></div>';
        
        echo '<hr />';
        
    	echo '<div class="row"><div class="col-xs-6 col-sm-6 col-md-6">';
    	
    	echo '<strong>Booking Summary:</strong><br />';
        
        echo '<img src="images/' . str_replace(' - Pay Later','',$row['type']) . '.png" width="200" />';
        
        echo '<strong>for ' . $row["make"] . ' ' . $row["model"] . ' ( ' . $row["regno"] . ' ) </strong><br />'; 
          	
    	echo '</div><div class="col-xs-6 col-sm-6 col-md-6">';
    	
    	echo '<br /><strong><i class="fa fa-inr"></i> ' . $row["price"] . '</strong>';
    	echo '<br /><strong>Payment Status: ' . $row["paymentstatus"] . '</strong>';
    	
        echo '</div></div>';

    }
} else {
    echo "Order Id is invalid";
}

mysqli_close($conn);


?>